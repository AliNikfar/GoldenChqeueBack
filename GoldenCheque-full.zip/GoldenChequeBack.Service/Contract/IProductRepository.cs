﻿
using GoldenChequeBack.Domain.Entities;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoldenChequeBack.Service.Contract
{
    public interface IProductRepository
    {
        Task<Product>  InsertAsync(Product objectt);

        Task<Product?> UpdateAsync(Product bank);

        Task<Product?> DeleteAsync(Guid Id);

        Task<IEnumerable<Product>> GetAllAsync();

        Task<Product?> GetById(Guid id);
        Task<bool> IsProductExsist(Product product);
    }
}
