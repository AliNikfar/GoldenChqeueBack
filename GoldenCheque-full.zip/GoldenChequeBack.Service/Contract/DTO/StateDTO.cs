﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoldenChequeBack.Service.Contract.DTO
{
    public class StateDTO
    {
        public Guid Id { get; set; }
        public string Name
        {
            get;
            set;
        }
    }
}
