﻿using GoldenChequeBack.Infrastructure.Middleware;
//using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Builder;
//using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http;
//using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Logging;
//using Serilog;

namespace GoldenChequeBack.Infrastructure.Extension
{
    public static class ConfigureContainer
    {
        public static void ConfigureCustomExceptionMiddleware(this IApplicationBuilder app)
        {
            app.UseMiddleware<CustomExceptionMiddleware>();
        }

        public static void ConfigureSwagger(this IApplicationBuilder app)
        {
            app.UseSwagger();

            app.UseSwaggerUI(setupAction =>
            {
                setupAction.SwaggerEndpoint("/swagger/v1/swagger.json", "My Test1 Api v1");
                setupAction.RoutePrefix = "OpenAPI";
            });
        }

        public static void ConfigureSwagger(this ILoggerFactory loggerFactory)
        {
            //loggerFactory.AddSerilog();
        }

        //public static void UseHealthCheck(this IApplicationBuilder app)
        //{
        //    app.UseHealthChecks("/healthz", new HealthCheckOptions
        //    {
        //        Predicate = _ => true,
        //        ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse,
        //        ResultStatusCodes =
        //        {
        //            [HealthStatus.Healthy] = StatusCodes.Status200OK,
        //            [HealthStatus.Degraded] = StatusCodes.Status500InternalServerError,
        //            [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable,
        //        },
        //    }).UseHealthChecksUI(setup =>
        //    {
        //        setup.ApiPath = "/healthcheck";
        //        setup.UIPath = "/healthcheck-ui";
        //    });
        //}
    }
}
