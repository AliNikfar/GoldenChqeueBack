﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoldenChequeBack.Domain.Enum
{
    public enum FeatureManagement
    {
        EnableEmailService
    }
}
